# daVIPA desktop icon set

Generated from `davipa-icon-crimson.png` (1254 × 1254, opaque RGB).

## Two framing variants

**`full-bleed/`** — the rounded card was located in the source (crop box 90, 78 → 1165, 1153;
1075 × 1075) and everything outside its rounded outline was made transparent. The corner is a
superellipse fitted to the source art: radius ≈ 304 px on the 1075 px card, exponent ≈ 2.66
(that is a corner radius of ~28% of the side — chunkier than Apple's 22.5%, so it was preserved
rather than normalised). Edges are anti-aliased by 4× supersampling.

**`as-is/`** — straight Lanczos downscales of the file you supplied, padding and drop shadow
intact, fully opaque.

## Contents (identical layout in both variants)

| Path | What it is |
| --- | --- |
| `macos/davipa.icns` | Ready-to-ship icon. Contains `icp4` 16, `icp5`/`ic11` 32, `ic12` 64, `ic07` 128, `ic13`/`ic08` 256, `ic14`/`ic09` 512, `ic10` 1024. |
| `macos/davipa.iconset/` | The same PNGs in Apple's `.iconset` layout, if you'd rather run `iconutil -c icns davipa.iconset` yourself. |
| `windows/davipa.ico` | Multi-resolution ICO: 16, 20, 24, 32, 40, 48, 64, 96, 128, 256. |
| `windows/davipa-<n>.png` | The same sizes as loose PNGs. |
| `png/davipa-<n>.png` | General-purpose set: 16, 24, 32, 48, 64, 128, 256, 512, 1024. |

`_preview.png` shows both variants over a checkerboard so the transparency is visible.

## Which variant to use where

- **macOS** does not mask app icons — the app supplies its own shape, shadow and margin. The
  `full-bleed/macos/` files follow Apple's grid: the rounded square occupies 824 of the 1024 pt
  canvas (100 pt margin on each side), with transparency around it. Use this one.
  `as-is/macos/` bakes in an opaque dark-navy square, which will read as a hard rectangle in the
  Dock and against light Finder backgrounds.
- **Windows** icons are conventionally full-bleed with transparent corners, so
  `full-bleed/windows/davipa.ico` is the right choice. `as-is` is provided for completeness.

## Known limitation

Below roughly 48 px the circle and square strokes fall under one pixel wide and disappear into
the gradient — at 16 and 24 px the icon reads as a coloured blob with a diagonal streak. If the
16/24/32 px sizes matter (Finder list view, Windows taskbar, title bars), those sizes need a
separately drawn mark: thicker strokes, or the arrow alone. I can produce that on request.
